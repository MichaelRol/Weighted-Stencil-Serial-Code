﻿Intel(R) System Studio 2019 Readme Files
======================================

This article contains installation Readme files for:

* Windows* Host Install
* macOS* Host Install
* Linux* Host Install

Windows* Host Install
=====================

I. Installing on Windows*

SERIAL NUMBER: When you register and download the package, you will receive your serial number in an email from Intel Registration Center.

1) For an *.exe file, run the *.exe file.
   For example, run system_studio_2019_ultimate_edition.exe
2) For a *.zip file, unpack the file. Then, from the unpacked folder, run setup.exe.
   For example, run .\system_studio_2019_ultimate_edition_offline\setup.exe
3) Follow the instructions in the installer. Note: To find your serial number, check for an email from Intel Registration Center.

II. Launching Intel(R) System Studio 2019 on Windows*

For a Linux* or Android* target

1) From the Start menu, select "Intel System Studio 2019 for Linux and Android targets" > "Intel(R) System Studio"
2) The Eclipse Launcher opens. Create the workspace in the user home directory
3) Click "OK" to launch Intel System Studio
4) Follow the instructions on the Getting Started welcome screen

For a Windows* target

1) From the Start menu, select "Intel System Studio for Windows target"
2) Then, select "Documentation and Getting Started with Intel System Studio 2019"
3) The Getting Started Guide opens
4) Open Microsoft Visual Studio*
5) Follow the instructions in the Getting Started Guide

macOS* Host Install

SERIAL NUMBER: When you register and download the package, you will receive your serial number in an email from Intel Registration Center.

I. Installing on macOS* - Graphic User Interface Mode

1) Mount the disk image (system_studio_2019.dmg).
2) Double-click the "install" icon to start install.app.
3) Follow the instructions in the installer. Note: To find your serial number, check for an email from Intel Registration Center.

II. Installing on macOS* - Command Line Interface Mode

1) Unpack the installer using command: "tar -zxf system_studio_2019_offline.tgz"
2) Run the installer: ""./system_studio_2019_offine/system_studio_2019.app"
3) Follow the instructions in the installer. Note: To find your serial number, check for an email from Intel Registration Center.

III. Launching Intel(R) System Studio 2019 on macOS*

1) In your Applications folder, navigate to "Intel System Studio 2019 for Linux* and Android* targets"
2) Double-click "Intel System Studio". The Intel System Studio Eclipse Launcher opens.
3) Create the workspace in the user home directory
4) Click "OK" to launch Intel System Studio

Linux* Host Install

SERIAL NUMBER: When you register and download the package, you will receive your serial number in an email from Intel Registration Center.

I. Installing on Linux* - Graphic User Interface Mode

1) Unpack the archive
2) Enter "$sudo ./install.sh" to launch the GUI installer
3) Follow the instructions in the installer. Note: To find your serial number, check for an email from Intel Registration Center.

II. Launching Intel(R) System Studio 2019  on Linux*

1) Double-click the "Intel(R) System Studio" desktop shortcut.
2) The Eclipse Launcher opens. Create the workspace in the user home directory.
3) Click "OK" to launch Intel System Studio

III. Installing on Linux* - Command Line Interface Mode

If your system does not support GUI-mode installation, you can install
Intel System Studio in the Command Line Interface (CLI) mode.

The CLI mode requires you to prepare a configuration file before launching the
installation. You can find a template of this configuration file in the
silent.cfg file included in the installation package. The silent.cfg template
contains all of the supported installation options together with their
descriptions and possible values.

III.1 Configuring the silent.cfg Template
-------------------------------------------------------------------------------

The following list contains the minimal set of changes you have to make to the
silent.cfg template:

1. Accept the conditions of the End User License Agreement (EULA) by
setting the value of ACCEPT_EULA to "accept".

   Example:
      # accept EULA, valid values are: {accept, decline}
      ACCEPT_EULA=accept

2. Specify the product activation type by setting the value of ACTIVATION_TYPE.
   Below are the most commonly used license activation methods:

   ACTIVATION_TYPE={exist_lic, license_server, license_file, serial_number}

   You can find the meaning of each of these values in the section "Appendix 1
   Activation Methods" below.

III.2 Launching Installation in CLI Mode
-------------------------------------------------------------------------------

To launch installation in the silent mode, run the following command, where
silent.cfg is the configuration file that resulted from editing the template:

$ sudo ./install.sh -s silent.cfg


Appendix 1 Activation Methods
-------------------------------------------------------------------------------
The activation methods supported in silent.cfg have the following meanings:

 - serial_number: the installer contacts an external Intel activation server

   and confirms the validity of the serial number stored in
   ACTIVATION_SERIAL_NUMBER.

   Example:
      ACTIVATION_TYPE=serial_number
      ...
      # Serial number, valid values are: {snpat}
      # snpat - the serial number pattern (ABCD-01234567)
      ACTIVATION_SERIAL_NUMBER=ABCD-01234567

 - exist_lic: the installer searches for an existing license on your machine.
   The search locations are the environment variable INTEL_LICENSE_FILE
   and the default license directory "/opt/intel/licenses/".

   Example:
      ACTIVATION_TYPE=exist_lic

 - license_file: the installer attempts to use the file specified in
   ACTIVATION_LICENSE_FILE as the license file.

   Example:
      ACTIVATION_TYPE=license_file
      ...
      # License file or license server, valid values are: {filepat}
      # filepat - the file location pattern (/file/location/to/license.lic)
      ACTIVATION_LICENSE_FILE=/file/location/to/license.lic

 - license_server: the installer contacts a floating license server on the
   local network to activate the product.

   Make sure your client is correctly set up for your network including all
   networking, routing, name service, and firewall settings. Ensure that your
   client has direct access to your floating license server and that firewalls
   are set up to allow TCP/IP access for the 2 license server ports.

   The installer takes the license information from INTEL_LICENSE_FILE.
   INTEL_LICENSE_FILE can contain either a server address in the port@hostname
   format or the path to a client license file. You can find a more detailed
   detailed description at
   https://software.intel.com/en-us/articles/licensing-setting-up-the-client-floating-license

   Example:
      ACTIVATION_TYPE=license_server
      ...
      # lspat - the license server address pattern (0123@hostname)
      INTEL_LICENSE_FILE=0123@hostname

 - No license file but you have a serial number: please visit
   https://registrationcenter.intel.com to register your serial number.
   As part of the registration, you will receive an email with an attached
   license file. If your serial number is already registered and you need to
   retrieve a license file, please read the following article:
   https://software.intel.com/en-us/articles/how-do-i-manage-my-licenses
